﻿namespace BashSoft
{
    public static class DirectoryInfo
    { 
    }
}
