﻿namespace BashSoft
{
    public class StartUp
    {
        public static void Main()
        {
            //IOManager.TraverseDirectory(0);
            //StudentsRepository.InitializeData(@"Files/dataNew.txt");
            //StudentsRepository.GetAllStudentsFromCourse("Unity");
            // StudentsRepository.GetStudentScoresFromCourse("Unity", "Ivan");

            //Tester.CompareContent(@"D:\Programming\C# Fundamentals\C# Advanced\StoryMode\BashSoft\Files\test2.txt", @"D:\Programming\C# Fundamentals\C# Advanced\StoryMode\BashSoft\Files\test3.txt");

            //IOManager.CreateDirectoryInCurrentFolder("pesho");
            //IOManager.ChangeCurrentDirectoryRelative(@"..");
            //IOManager.ChangeCurrentDirectoryRelative(@"..");
            //IOManager.ChangeCurrentDirectoryRelative(@"..");
            //IOManager.ChangeCurrentDirectoryRelative(@"..");
            //IOManager.ChangeCurrentDirectoryRelative(@"..");
            //IOManager.ChangeCurrentDirectoryRelative(@"..");
            //IOManager.ChangeCurrentDirectoryAbsolute(@"C:\Windows");

            InputReader.StartReadingCommands();

        }
    }
}
